<?php 
$info = json_decode(file_get_contents('/root/ch/turbo/info.json'),true);
if(!file_exists('info.json')) { 
$token =  readline("- Enter Token : ");
$id = readline("- Enter Id Sudo : ");
$info["token"] = "$token";
file_put_contents('/root/ch/turbo/info.json', json_encode($info));
$info["id"] = "$id";
file_put_contents('/root/ch/turbo/info.json', json_encode($info));
$info["name"] = "a";
file_put_contents('/root/ch/turbo/info.json', json_encode($info));
}
$token = $info["token"];
define('API_KEY',$token);
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res,true);
    }
}
function states($g) {
$st = "";
$x = shell_exec("pm2 show $g");
if(preg_match("/online/", $x)) {
$st = "run";
}else{
$st = "stop";
}
return $st;
}
function ren(){
$s = "";
for($i=0; $i<=10; $i++){
$s1 = substr(str_shuffle(str_repeat("abcdefghijklmnopqrstuvwxyz", 1)), 0, 1);
$s2 = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 1)), 0, 1);
$n = rand(0,4);
if($n == 0){
$s .= $s1.$s1.$s1.$s1.$s2."<br>";
}elseif($n == 1){
$s .= $s1.$s2.$s2.$s2.$s2."<br>";
}elseif($n == 2){
$s .= $s1.$s2.$s1.$s1.$s1."<br>";
}elseif($n == 3){
$s .= $s1.$s1.$s2.$s1.$s1."<br>";
}elseif($n == 4){
$s .= $s1.$s1.$s1.$s2.$s1."<br>";
}
}
return $s;
}
$lastupdid = 1; 
while(true){ 
 $upd = bot("getUpdates", ["offset" => $lastupdid]); 
 if(isset($upd['result'][0])){ 
  $text = $upd['result'][0]['message']['text']; 
  $chat_id = $upd['result'][0]['message']['chat']['id']; 
$from_id = $upd['result'][0]['message']['from']['id']; 
$message = $upd['result'][0]['message']; 
$nn = bot('getme', ['bot']) ["result"]["username"];
$info = json_decode(file_get_contents('/root/ch/turbo/info.json'),true);
$value = "";
$admin = $info["id"];
if ($chat_id == $admin) {
if ($text == "/start") {
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- تم البعص من قبل تيم القرامه  ~ 
- Click on the command you want ~
-𓂺 /s1 = commands File {1}
-𓂺 /s2 = commands File {2}
-𓂺 /s3 = commands File {3}
-𓂺 /s4 = commands File {4}",
 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" => "Status Files"]]],])]);
}
if($text == "Status Files") {
$a = states("a");
$z = states("z");
$s = states("s");
$e = states("e");
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- Checksتيم القرامه
▷ - File Num {1} : $a   ➢
▷ - File Num {2} : $z ➢
▷ - File Num {3} : $s   ➢
▷ - File Num {4} : $e.  ➢",
]);}

if($text == "/s1") {
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- تم البعص من قبل تيم القرامه  commands File {1} .",
 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" => "Run File {1}"], 
["text" => "Stop File {1}"]],
[["text" => "Pin User File {1}"], 
["text" => "unpin File {1}"]], 
[["text" => "Users File {1}"],
["text" => "Del Users File {1}"]], 
[["text" => "Rendom File {1}"]],
[["text" => "login File {1}"]]],])]);
}
if ($text == "Run File {1}") {
system("pm2 stop a.php");
system("pm2 start a.php");
}
if($text == "Pin User File {1}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /add @USER \n For pinned",
]);
}
if($text == "unpin File {1}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /unpin @USER \n For unpin",
]);
}
if ($text == "Stop File {1}") {
system("pm2 stop a.php");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done stoped File {1}"]);
   }
if($text == "login File {1}") {
system('rm -rf m1.madeline');
system('rm -rf m1.madeline.lock');
file_put_contents("step","");
if(file_get_contents("step") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"Send me Number Phone\n ex +**",
]);
file_put_contents("step","2");
  system('php ph1.php');
}
}
if(preg_match('/\/add (.*)/',$text)){
$str = str_replace("@","",$text);
$ex = explode('/add ',$str);
$se = str_replace(" ","\n",$ex[1]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Pin , ",
]);
if(file_exists('users1')) { 
file_put_contents("users1","\n".$se,FILE_APPEND);
}elseif(!file_exists('users1')) { 
file_put_contents("users1",$se,FILE_APPEND);
}
}
if(preg_match('/\/unpin (.*)/',$text)){
$us = str_replace("@","",$text);
$user = explode('/unpin ',$us)[1];
$users = explode("\n",file_get_contents("users1"));
if(in_array($user, $users)){
$se = str_replace("\n$user","",file_get_contents("users1"));
file_put_contents("users1",$se);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done .",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"this user no exist in list",
]);
}
}
if($text == "Users File {1}"){
if(file_exists("users1")){
$se = explode("\n",file_get_contents("users1"));
$u = "";
for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." - | @".$se[$i]."\n";
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" - The users : \n".$u,
]);
$u = "";
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" No users in list ",
]);
}
}
if($text == 'Del Users File {1}'){
unlink("users1");
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- Done Del All ,",
]);
}
if($text == "Rendom File {1}") {
$s = ren();
$str = str_replace("<br>","\n",$s);
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"`$str` \n-Send /add + past list \n-Ex /add uuhuu
ooroo
hohhh
dcccc ",
'parse_mode'=>'MarkDown',
]);
}
if($text == "/s2") {
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- تم البعص من قبل تيم القرامه  commands File {2} .",
 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" => "Run File {2}"], 
["text" => "Stop File {2}"]],
[["text" => "Pin User File {2}"], 
["text" => "unpin File {2}"]], 
[["text" => "Users File {2}"],
["text" => "Del Users File {2}"]], 
[["text" => "Rendom File {2}"]],
[["text" => "login File {2}"]]],])]);
}
if($text == "Pin User File {2}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /add2 @USER \n For pinned",
]);
}
if($text == "unpin File {2}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /unpin2 @USER \n For unpin",
]);
}
if ($text == "Run File {2}") {
system("pm2 stop z.php");
system("pm2 start z.php");
}
if ($text == "Stop File {2}") {
system("pm2 stop z.php");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done stoped File {2}"]);
   }
if($text == "login File {2}") {
system('rm -rf m2.madeline');
system('rm -rf m2.madeline.lock');
file_put_contents("step","");
if(file_get_contents("step") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"Send me Number Phone\n ex +**",
]);
file_put_contents("step","2");
  system('php ph2.php');
}
}
if(preg_match('/\/add2 (.*)/',$text)){
$str = str_replace("@","",$text);
$ex = explode('/add2 ',$str);
$se = str_replace(" ","\n",$ex[1]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Pin , ",
]);
if(file_exists('users1')) { 
file_put_contents("users2","\n".$se,FILE_APPEND);
}elseif(!file_exists('user2')) { 
file_put_contents("users2",$se,FILE_APPEND);
}
}
if(preg_match('/\/unpin2 (.*)/',$text)){
$us = str_replace("@","",$text);
$user = explode('/unpin2 ',$us)[1];
$users = explode("\n",file_get_contents("users2"));
if(in_array($user, $users)){
$se = str_replace("\n$user","",file_get_contents("users2"));
file_put_contents("users2",$se);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done .",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"this user no exist in list",
]);
}
}
if($text == "Users File {2}"){
if(file_exists("users2")){
$se = explode("\n",file_get_contents("users2"));
$u = "";
for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." - | @".$se[$i]."\n";
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" - The users : \n".$u,
]);
$u = "";
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" No users in list ",
]);
}
}
if($text == 'Del Users File {2}'){
unlink("users2");
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- Done Del All ,",
]);
}
if($text == "Rendom File {2}") {
$s = ren();
$str = str_replace("<br>","\n",$s);
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"`$str` \n-Send /add2 + past list \n-Ex /add uuhuu
ooroo
hohhh
dcccc ",
'parse_mode'=>'MarkDown',
]);
}
if($text == "/s3") {
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- تم البعص من قبل تيم القرامه  commands File {3} .",
 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" => "Run File {3}"], 
["text" => "Stop File {3}"]],
[["text" => "Pin User File {3}"], 
["text" => "unpin File {3}"]], 
[["text" => "Users File {3}"],
["text" => "Del Users File {3}"]], 
[["text" => "Rendom File {3}"]],
[["text" => "login File {3}"]]],])]);
}
if($text == "Pin User File {3}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /add3 @USER \n For pinned",
]);
}
if($text == "unpin File {3}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /unpin3 @USER \n For unpin",
]);
}
if ($text == "Run File {3}") {
system("pm2 stop s.php");
system("pm2 start s.php");
}
if ($text == "Stop File {3}") {
system("pm2 stop s.php");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done stoped File {3}"]);
   }
if($text == "login File {3}") {
system('rm -rf m3.madeline');
system('rm -rf m3.madeline.lock');
file_put_contents("step","");
if(file_get_contents("step") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"Send me Number Phone\n ex +**",
]);
file_put_contents("step","2");
  system('php ph3.php');
}
}
if(preg_match('/\/add3 (.*)/',$text)){
$str = str_replace("@","",$text);
$ex = explode('/add3 ',$str);
$se = str_replace(" ","\n",$ex[1]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Pin , ",
]);
if(file_exists('users1')) { 
file_put_contents("users3","\n".$se,FILE_APPEND);
}elseif(!file_exists('users3')) { 
file_put_contents("users3",$se,FILE_APPEND);
}
}
if(preg_match('/\/unpin3 (.*)/',$text)){
$us = str_replace("@","",$text);
$user = explode('/unpin3 ',$us)[1];
$users = explode("\n",file_get_contents("users3"));
if(in_array($user, $users)){
$se = str_replace("\n$user","",file_get_contents("users3"));
file_put_contents("users3",$se);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done .",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"this user no exist in list",
]);
}
}
if($text == "Users File {3}"){
if(file_exists("users3")){
$se = explode("\n",file_get_contents("users3"));
$u = "";
for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." - | @".$se[$i]."\n";
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" - The users : \n".$u,
]);
$u = "";
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" No users in list ",
]);
}
}
if($text == 'Del Users File {3}'){
unlink("users3");
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- Done Del All ,",
]);
}
if($text == "Rendom File {3}") {
$s = ren();
$str = str_replace("<br>","\n",$s);
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"`$str` \n-Send /add3 + past list \n-Ex /add uuhuu
ooroo
hohhh
dcccc ",
'parse_mode'=>'MarkDown',
]);
}
if($text == "/s4") {
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- تم البعص من قبل تيم القرامه  commands File {4} .",
 'reply_markup' => json_encode(['resize_keyboard' => true, 'keyboard' => [
[["text" => "Run File {4}"], 
["text" => "Stop File {4}"]],
[["text" => "Pin User File {4}"], 
["text" => "unpin File {4}"]], 
[["text" => "Users File {4}"],
["text" => "Del Users File {4}"]], 
[["text" => "Rendom File {4}"]],
[["text" => "login File {4}"]]],])]);
}
if($text == "Pin User File {4}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /add4 @USER \n For pinned",
]);
}
if($text == "unpin File {4}"){
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' =>" - Send  : /unpin4 @USER \n For unpin",
]);
}
if ($text == "Run File {4}") {
system("pm2 stop e.php");
system("pm2 start e.php");
}
if ($text == "Stop File {4}") {
system("pm2 stop s.php");
bot('sendMessage', [
'chat_id' => $chat_id, 
'text' => "Done stoped File {4}"]);
   }
if($text == "login File {4}") {
system('rm -rf m4.madeline');
system('rm -rf m4.madeline.lock');
file_put_contents("step","");
if(file_get_contents("step") == ""){
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"Send me Number Phone\n ex +**",
]);
file_put_contents("step","2");
  system('php ph4.php');
}
}
if(preg_match('/\/add4 (.*)/',$text)){
$str = str_replace("@","",$text);
$ex = explode('/add4 ',$str);
$se = str_replace(" ","\n",$ex[1]);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done Pin , ",
]);
if(file_exists('users1')) { 
file_put_contents("users4","\n".$se,FILE_APPEND);
}elseif(!file_exists('users4')) { 
file_put_contents("users4",$se,FILE_APPEND);
}
}
if(preg_match('/\/unpin4 (.*)/',$text)){
$us = str_replace("@","",$text);
$user = explode('/unpin4 ',$us)[1];
$users = explode("\n",file_get_contents("users4"));
if(in_array($user, $users)){
$se = str_replace("\n$user","",file_get_contents("users4"));
file_put_contents("users4",$se);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"- Done .",
]);
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"this user no exist in list",

]);
}
}
if($text == "Users File {4}"){
if(file_exists("users4")){
$se = explode("\n",file_get_contents("users4"));
$u = "";
for($i=0; $i<count($se); $i++){
$n1 = $i + 1;
$u .= $n1." - | @".$se[$i]."\n";
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" - The users : \n".$u,
]);
$u = "";
}else{
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>" No users in list ",
]);
}
}
if($text == 'Del Users File {4}'){
unlink("users4");
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"- Done Del All ,",
]);
}
if($text == "Rendom File {4}") {
$s = ren();
$str = str_replace("<br>","\n",$s);
bot('sendmessage',[
'chat_id'=>$chat_id, 
'text'=>"`$str` \n-Send /add4 + past list \n-Ex /add uuhuu
ooroo
hohhh
dcccc ",
'parse_mode'=>'MarkDown',
]);
}
}
$lastupdid = $upd['result'][0]['update_id'] + 1; 
} 
}